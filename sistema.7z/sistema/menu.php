
<?php
function generarMenu($padre_id = NULL) {
    include 'config.php';
    $sql = "SELECT id, nombre, enlace FROM menu WHERE padre_id " . ($padre_id ? "= $padre_id" : "IS NULL");
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<ul class='menu'>";
        while ($row = $result->fetch_assoc()) {
            echo "<li><a href='" . $row['enlace'] . "'><i class='fas fa-" . strtolower($row['nombre']) . "'></i> " . $row['nombre'] . "</a>";
            generarMenu($row['id']);
            echo "</li>";
        }
        echo "</ul>";
    }
    $conn->close();
}
?>