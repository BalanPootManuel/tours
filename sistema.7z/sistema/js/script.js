

document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const menu = document.querySelector('ul.menu');

    menuToggle.addEventListener('click', function() {
        menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
    });

    const menuItems = document.querySelectorAll('ul.menu li');
    menuItems.forEach(item => {
        item.addEventListener('mouseover', function() {
            const submenu = this.querySelector('ul');
            if (submenu) {
                submenu.style.display = 'block';
            }
        });
        item.addEventListener('mouseout', function() {
            const submenu = this.querySelector('ul');
            if (submenu) {
                submenu.style.display = 'none';
            }
        });
    });
});