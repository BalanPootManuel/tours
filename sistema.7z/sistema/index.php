<?php
session_start();
include 'config.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Tours</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js" defer></script>
</head>
<body>
    <div class="header">
        <h1>Bienvenido a Nuestro Portal de Tours</h1>
        <div class="menu-toggle">Menú</div>
    </div>
    <div class="sidebar">
        <?php include 'menu.php'; generarMenu(); ?>
    </div>
    <div class="main-content">
        <div class="gallery-container">
            <h2>Nuestros Tours</h2>
            <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] == 'admin'): ?>
                <a href="upload.php" class="add-button">Agregar Nuevo Tour</a>
            <?php endif; ?>
            <div class="gallery">
                <?php
                $sql = "SELECT id, nombre, descripcion, imagen FROM tours";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='gallery-item'>
                                <img src='" . $row["imagen"] . "' alt='" . $row["nombre"] . "' class='gallery-image'>
                                <div class='overlay'>
                                    <div class='text'>" . $row["descripcion"] . "</div>
                                </div>
                              </div>";
                    }
                } else {
                    echo "<p>No hay tours disponibles.</p>";
                }
                $conn->close();
                ?>
            </div>
        </div>
    </div>
</body>
</html>